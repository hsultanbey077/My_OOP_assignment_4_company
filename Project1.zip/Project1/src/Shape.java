
import java. io.BufferedWriter;
import java. io.FileWriter;
import java. io.File; // Import the File class
import java. io.FileNotFoundException; // Impo
import java.util.Scanner;

public class Shape{

Point[] points = new Point[999];
int index = 0;

    public Shape() throws FileNotFoundException {
    }

    public void addPoints(int x, int y){
    points[index++] = new Point(x, y);
    System.out.println(x+y);
}
    int index1 = 0;
public void averageLength(int x ,int y ){
    points[index1++]=new Point(x,y);
    System.out.println(x/2);
    System.out.println(y/2);
}
    int index2 = 0;
    public double longest(int x, int y){
        points[index2++]=new Point(x,y);
        if(x>y)
            return x;
        else
            return y;
    }

}