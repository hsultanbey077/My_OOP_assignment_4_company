import java.io.File;
import java.io.FileNotFoundException;
import java.text.ParseException;
import java.util.Scanner;

public class Assignment1 {
    public static void main(String[] args) throws ParseException, FileNotFoundException {
        Scanner in=new Scanner(System.in);
        Point a=new Point (1,2);
        Point b= new Point(3,4);

        System.out.println(a.getx());
        System.out.println(b.getx());

        System.out.println(a.distance(b));



        File file = new File(  "D:/Users/Sultan/File1.txt");
        Scanner scan = new Scanner(file);

        Shape g = new Shape();
        g. addPoints(99,77);
        for (int j=0;j<g.index;j++){
            System. out. println(j);
    }
        Shape z =new Shape();

        for (int j=0;j<z.index1;j++){
            z.averageLength(45,25);
            System. out. println(j);
        }
        Shape w= new Shape();

        w.longest(36,76);
        for (int j=0;j<w.index2;j++){
            System. out. println(j);
        }
    }
}
