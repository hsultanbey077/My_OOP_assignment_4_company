public class Point {
    private int x;
    private int y;
    public Point(int x, int y) {
        this.x = x;
        this.y = y;
    }
    public int getx(){
        return x;
    }
    public void setx(int x){
        this.x=x;
    }
    public int gety(){
        return y;
    }
    public void sety(int y){
        this.y=y;
    }

    public void average(){
        System.out.println(x-y);
    }
    double distance(Point p1){
        return Math. sqrt((Math.pow((x - p1.getx()), 2)) + (Math. pow((y - p1.gety()),2)));
    }

}
